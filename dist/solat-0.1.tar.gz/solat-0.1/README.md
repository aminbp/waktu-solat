# solat

'solat' is a python API for malaysia prayer times. This API is using JAKIM prayer times as references
